
public class Saque
{
   private int tipo,id_movimento;
   
   public Saque(int id_movimento)
   {
      tipo = 0;
      this.id_movimento = id_movimento;
   }
   
   public void incluiSaque()
   {
	  SaqueTO to = new SaqueTO(getIDMovimento());
      SaqueDAO s = new SaqueDAO();
      
      s.incluir(to);
   
   }
   
   public int getIDMovimento()
   {
      return id_movimento;
   }
}