
public class SaqueTO {
	  private int tipo,id_movimento;

	   public SaqueTO(int id_movimento)
	   {
	      tipo = 0;
	      this.id_movimento = id_movimento;
	   }

	public int getTipo() {
		return 0;
	}

	public int getId_movimento() {
		return id_movimento;
	}
	   
}
