
import java.sql.*;

public class SaqueDAO{

private int tipo,id_movimento;
   
   public SaqueDAO()
   {
      tipo = 0;
      this.id_movimento = 0;
   }

   public void incluir(SaqueTO to) 
   
   { 
   
      String sqlInsert = "insert into saque(tipo_movimento,id_movimento) VALUES (?, ?)";   

      try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlInsert);)  {
                
      
         stm.setInt(1, to.getTipo()); 
      
         stm.setInt(2, to.getId_movimento()); 
         
         stm.execute(); 
      
           
      } catch (SQLException e) {
			e.printStackTrace();
		}
  }  
   
}
