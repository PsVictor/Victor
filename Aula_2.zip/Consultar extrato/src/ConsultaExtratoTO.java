import javax.swing.*;
import java.awt.*;
import javax.swing.table.*;
import java.sql.*;
import java.text.*;
import java.util.Date;
public class ConsultaExtratoTO{
	
	private JTable tabela;
	
	public ConsultaExtratoTO(JTable tabela)
	{
		this.tabela = tabela;
	}
	
	public JTable getTable()
	{
		return tabela;
	}
}
