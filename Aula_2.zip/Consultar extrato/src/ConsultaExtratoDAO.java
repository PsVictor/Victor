
import javax.swing.*;
import java.awt.*;
import javax.swing.table.*;
import java.sql.*;
import java.text.*;
import java.util.Date;

public class ConsultaExtratoDAO extends JFrame
{	
	private JPanel painel;
	private JTable tabela;
	private JScrollPane barraRolagem;
	final DefaultTableModel modelo;
	private int id_conta;
   private Date data;
	private ConsultaExtratoTO to;

	public ConsultaExtratoDAO(int id_conta,Date data){
		super("Extrato");
      this.id_conta = id_conta;
      this.data = data;
	 	modelo = new DefaultTableModel();
		tabela = new JTable(modelo);
		
		modelo.addColumn("Data");
   	modelo.addColumn("Valor");
   	modelo.addColumn("Conta");
    	modelo.addColumn("Tipo do Movimento");
		
      String query = "select * from movimento where id_conta = ? and data_movimento >= ?";
      try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(query);) {
      
		stm.setInt(1,id_conta);
      stm.setDate(2,new java.sql.Date(data.getTime()));
      ResultSet rs = stm.executeQuery();
		while(rs.next()){ 
        int id_movimento = rs.getInt(1);
        String date = rs.getString(2);
        int valor = rs.getInt(3);
        int conta = rs.getInt(4);
        int tipo_movimento = rs.getInt(5);
        modelo.addRow(new Object[]{new String(date), valor, conta, tipo_movimento});
      }
			to = new ConsultaExtratoTO(tabela);
		}
		  catch(SQLException ex){
           System.out.println("SQLException: " + ex.getMessage());
           System.out.println("SQLState: " + ex.getSQLState());
           System.out.println("VendorError: " + ex.getErrorCode());
      }
      catch(Exception e){
        System.out.println("Problemas ao tentar conectar com o banco de dados");	
    }
		
	}
	
		public JTable getTabela()
		{
			return to.getTable();
		}
		
}
	