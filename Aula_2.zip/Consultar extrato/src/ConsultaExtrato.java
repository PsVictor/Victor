import javax.swing.table.*;
import java.util.ArrayList;
import java.util.Date;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import javax.swing.*;
import java.util.*;


public class ConsultaExtrato extends JFrame {
	private static int dias_a_avancar;
	private int conta;
	private static String data;
	public String valores;
	
	public ConsultaExtrato(int dias_a_avancar, int conta) {
		this.dias_a_avancar = dias_a_avancar;
		this.conta = conta;
	}

	public void pegarExtrato(){
   
      Calendar c = Calendar.getInstance();  
      //c.add(Calendar.DATE, -31);  
      //System.out.println(dateFormat.format(c.getTime())); 
      if (dias_a_avancar == 7){
          c.add(Calendar.DATE, -7);
          ConsultaExtratoDAO consultaExtratoDAO = new ConsultaExtratoDAO(conta,c.getTime());
         criarJanela(consultaExtratoDAO.getTabela());  
      }
      else if(dias_a_avancar == 15){
            c.add(Calendar.DATE, -15);
            ConsultaExtratoDAO consultaExtratoDAO = new ConsultaExtratoDAO(conta,c.getTime());
          criarJanela(consultaExtratoDAO.getTabela());
      }
      else
      {
         c.add(Calendar.DATE,dias_a_avancar*-1);
         ConsultaExtratoDAO consultaExtratoDAO = new ConsultaExtratoDAO(conta,c.getTime());
         criarJanela(consultaExtratoDAO.getTabela());
      }
	}
	
	public void criarJanela(JTable tabela){
		
		tabela.setPreferredScrollableViewportSize(new Dimension(500, 500));
		JPanel painel = new JPanel();
		painel.setLayout(new FlowLayout());
		JScrollPane barraRolagem = new JScrollPane(tabela);
		painel.add(barraRolagem);
		
		getContentPane().add(painel);
		setSize(525,300);
		setVisible(true);		
	}
}